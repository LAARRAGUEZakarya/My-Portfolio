<!-- page header -->
<header id="home" class="header">
    <div class="overlay"></div>
    <div class="header-content container">
        <h1 class="header-title">
            <span class="up">HI!</span>
            <span class="down">I am LAARRAGUE Zakarya</span>
        </h1>
        <p class="header-subtitle">FULL-STACK DEVELOPER</p>

        <a href="#portfolio" class="btn btn-primary">Visit My Works</a>
    </div>
</header><!-- end of page header -->
<?php /**PATH E:\ProjectsInGitHub\LARAVEL PROJECTS\My Portfolio\My_Portfolio\resources\views/layout/header.blade.php ENDPATH**/ ?>