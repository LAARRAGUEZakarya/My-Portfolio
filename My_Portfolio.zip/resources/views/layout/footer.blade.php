<!-- footer -->
<div class="container">
    <footer class="footer">
        <p class="mb-0">Copyright 2023 &copy; <a href="https://www.linkedin.com/in/laarrague-zakarya-3085ba1bb/" target="_blank">LAARRAGUE Zakarya</a></p>
        <div class="social-links text-right m-auto ml-sm-auto">
            <a href="javascript:void(0)" class="link" target="_blank"><i class="ti-facebook"></i></a>
            <a href="javascript:void(0)" class="link" target="_blank"><i class="ti-twitter-alt"></i></a>
            <a href="mailto:laarraguezakarya@gmail.com" class="link" target="_blank"><i class="ti-google"></i></a>
            <a href="javascript:void(0)" class="link" target="_blank"><i class="ti-pinterest-alt" ></i></a>
            <a href="javascript:void(0)" class="link" target="_blank"><i class="ti-instagram"></i></a>
            <a href="https://www.linkedin.com/in/laarrague-zakarya-3085ba1bb/" class="link" target="_blank"><i class="ti-linkedin"></i></a>
            <a href="javascript:void(0)" class="link" target="_blank"><i class="ti-rss"></i></a>
        </div>
    </footer>
</div> <!-- end of page footer -->
