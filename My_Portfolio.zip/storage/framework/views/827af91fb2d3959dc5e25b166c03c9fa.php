 <!-- contact section -->
 <section class="section" id="contact">
    <div class="container text-center">
        <p class="section-subtitle">How can you communicate?</p>
        <h6 class="section-title mb-5">Contact Me</h6>
        <!-- contact form -->
        <form action="<?php echo e(route('sendMail')); ?>" method="POST" class="contact-form col-md-10 col-lg-8 m-auto">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-sm-6">
                    <input type="text" name="name" size="50" class="form-control" placeholder="Your Name" required>
                </div>
                <div class="form-group col-sm-6">
                    <input type="email" name="email"  class="form-control" placeholder="Enter Email"requried>
                </div>
                <div class="form-group col-sm-12">
                    <textarea  name="message"  id="comment" rows="6"   class="form-control" placeholder="Write Something"></textarea>
                </div>
                <div class="form-group col-sm-12 mt-3">
                    <input type="submit" value="Send Message" class="btn btn-outline-primary rounded">
                </div>
            </div>
        </form><!-- end of contact form -->
    </div><!-- end of container -->
</section><!-- end of contact section -->
<?php /**PATH E:\ProjectsInGitHub\LARAVEL PROJECTS\My Portfolio\My_Portfolio\resources\views/sections/contact.blade.php ENDPATH**/ ?>