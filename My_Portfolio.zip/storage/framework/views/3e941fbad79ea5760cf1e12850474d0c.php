 <!-- testimonial section -->
 <section class="section" id="testmonial">
    <div class="container text-center">
        <p class="section-subtitle">What Think Client About Me ?</p>
        <h6 class="section-title mb-6">Testmonial</h6>

        <!-- row -->
        <div class="row">
            <div class="col-md-6">
                <div class="testimonial-card">
                    <div class="testimonial-card-img-holder">
                        <img src="assets/imgs/MarrackechQuadFlying.jpeg" class="testimonial-card-img" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page">
                    </div>
                    <div class="testimonial-card-body">
                        <p class="testimonial-card-subtitle">I have been using Marrackech Quad Flying for over a year now and I love it! I can't imagine life without it. It's so easy to use, and the customer service is great.</p>
                        <h6 class="testimonial-card-title">Marrackech Quad Flying</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="testimonial-card">
                    <div class="testimonial-card-img-holder">
                        <img src="assets/imgs/avatar3.png" class="testimonial-card-img" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page">
                    </div>
                    <div class="testimonial-card-body">
                        <p class="testimonial-card-subtitle">I love FONDATIONAMANE! This is an amazing service and it has saved me and my small business so much time. I plan to use it for a long time to come</p>
                        <h6 class="testimonial-card-title">E L MOTIAA Manal</h6>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- end of container -->
</section> <!-- end of testimonial section -->
<?php /**PATH E:\ProjectsInGitHub\LARAVEL PROJECTS\My Portfolio\My_Portfolio\resources\views/sections/testmonial.blade.php ENDPATH**/ ?>