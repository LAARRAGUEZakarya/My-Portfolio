<?php
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
?>


<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    window.Toast = Swal.mixin({
        toast: true,
        position: 'top',

        iconColor: 'white',
        customClass: {
            popup: 'colored-toast'
        },
        showConfirmButton: false,
        timer: 4000,
        timerProgressBar: true
    });
</script>





<?php if(session()->has('success')): ?>
    <script>
        window.Toast.fire({
            icon: "success",
            background:'#695AA6',
            color:'white',
            text: "<?php echo session()->get('success'); ?>",
        });
    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        window.Toast.fire({
            background:'#FF0F0F',
            color:'white',
            icon: "error",
            text: "<?php echo session()->get('error'); ?>",
        });
    </script>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
    <script type="text/javascript">
        window.Toast.fire({
            background:'#FF0F0F',
            color:'white',
            icon: 'error',
            text: "Something went wrong",
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\ProjectsInGitHub\LARAVEL PROJECTS\My Portfolio\My_Portfolio\resources\views/layout/helper/alerts.blade.php ENDPATH**/ ?>